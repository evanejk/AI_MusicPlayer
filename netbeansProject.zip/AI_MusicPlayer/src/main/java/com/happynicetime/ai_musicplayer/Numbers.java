/*
 * copyright Evan James Kizer 2024
 * nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 */
package com.happynicetime.ai_musicplayer;

import java.util.Random;

class Numbers {
    static Random rand = new Random();
    static int getRandomNumber() {
        return rand.nextInt();
    }
    
}

